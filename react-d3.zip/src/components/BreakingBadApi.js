import React, {useEffect, useState, useRef} from 'react';
import BBTimeline from './BBTimeline';

function BreakingBadApi(){
    const videoRef = useRef();
    const [bbEpisodes, setBbEpisodes] = useState([]);
    const [highlight, setHighlight] = useState();
    useEffect(()=>{
        fetch('https://wwww.breakingbadapi.com/api/characters?category=Breaking+Bad')
        .then(response => response.ok && response.json())
        .then(characters => {
         setBbEpisodes(
             characters.sort((a, b) => a.name.localeCompare(b.name))
         );
        })
        .catch(console.error);
    }, []);
    
}