import React, {useRef, useEffect, useState} from 'react';
import './LineChart.css';
import {select, line, curveCardinal, axisBottom, axisRight, scaleLinear} from 'd3';


const LineChart = () => {
    const [data, setData] = useState([25, 30, 45, 60, 20, 65, 75]);
    const svgRef = useRef();
    useEffect(() =>{
     const svg = select(svgRef.current);
     const xScale = scaleLinear()
     .domain([0, data.length - 1])
     .range([0, 300]);
     const yScale = scaleLinear()
    //  .domain([0, 75])
    .domain([0, 150])
     .range([150, 0]);
     const xAxis = axisBottom(xScale).ticks(data.length).tickFormat(index => index +1); //ca sa se numere de la 1 nu de la 0
     svg.select('.x-axis').style('transform', 'translateY(150px)').call(xAxis);
    //  xAxis(svg.select('x-axis'))
    const yAxis = axisRight(yScale);
    svg.select('.y-axis').style('transform', 'translateX(300px)').call(yAxis);
     const myLine = line()
    //  .x((value, index) => index *50)
    .x((value, index) => xScale(index))
    //  .y(value => 150 - value)
    // .y(value => yScale(value))
    .y(yScale)
     .curve(curveCardinal); //pentru a o face valoroasa
     svg
    //  .selectAll('path')
    .selectAll('.line')
     .data([data])
     .join('path')
    //  .attr("d", value => myLine(value))
     .attr('class', 'line')
     .attr("d", myLine)
     .attr('fill', 'none')
     .attr('stroke', 'blue')
    }, [data]);
        return(
            <React.Fragment>
                <svg ref={svgRef}>
                   <g className="x-axis"/>
                   <g className="y-axis"/>
                </svg>
                <br/>
                <br/>
                <br/>
                <button onClick={() => setData(data.map(value => value + 5))}>Update data</button>
                <br/>
                <button onClick={() => setData(data.filter(value => value < 35))}>Filter data</button>
            </React.Fragment>
        )
}
export default LineChart;