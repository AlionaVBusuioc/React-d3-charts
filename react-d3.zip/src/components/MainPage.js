import React, { Component } from 'react';
import './MainPage.css';
import {Nav} from 'react-bootstrap';
import { BrowserRouter as Router, Route, Switch} from 'react-router-dom';
import D3Chart from './D3Chart';
import LineChart from './LineChart';
import BarChart from './BarChart';
import Interactivity from './Interactivity';


export default class MainPage extends Component {
    render(){
        
        return(
            <div>
            <Nav className="arrange">
            <Nav.Item>
            <Nav.Link  href="/circle">Circle Chart</Nav.Link>
            </Nav.Item>
            <Nav.Item>
            <Nav.Link href="/line">Line Chart</Nav.Link>
            </Nav.Item>
            <Nav.Item>
            <Nav.Link  href="/bar">Bar Chart</Nav.Link>
            </Nav.Item>
            <Nav.Item>
            <Nav.Link  href="/interactivity">InteractivityBar Chart</Nav.Link>
            </Nav.Item>
            </Nav>
             <p className="arrange line">_______________________________________________________________________________________________</p>
             <Router>
             <Switch>
              <Route path="/circle"
              component={D3Chart}
              />
               <Route path="/line"
              component={LineChart}
              />
               <Route path="/interactivity"
              component={Interactivity}
              />
               <Route path="/bar"
              component={BarChart}
              />
             </Switch>
             </Router>
         </div>
        )
    }
}